# .gitignore 

~~~
  # ju -- https://bw1.eu -- 10-Okt-18  -- .gitignore                                                                   
  # ordner/
  # !file.md = Ausnahme, wird versioniert

  !.gitignore



  #*.pdf
  #*.jpg

  *.exe
  *.x

  # ordner
  #docx/             # Word                                                           
  html/                                                                                                                                                
  imgOriginal/                                                                 
  imgWebTex/                                                                                                                                           
  pdf/                                                                         
  tex/

  # HTML                                                                                                                               
  *.html                                                                   

  # Latex
  *-main.tex
  *-book.tex
  *-print.tex
  *.log
  *.out
  *.aux 
  *.synctex*
  *.bbl
  *.bcf
  *.blg
  *.run*
~~~


