# Dokumentvorlage (LaTeX)

Modified source from v.14

<https://www.dcl.hpi.uni-potsdam.de/media/theses/>

## Literaturverzeichnis, Zitate und Quellenangaben

Tool <https://www.zotero.org/>

## Rechtschreibung & Grammatik

<https://www.duden.de/Liste-der-rechtschreiblich-schwierigen-Woerter>

## Drucken & Binden

<http://www.potsdam-druck.de/digitaldruck/softcoverbuecher-drucken-binden.html>