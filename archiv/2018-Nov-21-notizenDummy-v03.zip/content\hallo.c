/* ju -- 2-Juni-17 -- hallo.c */
#include <stdio.h>
int main(void){
	printf("Hallo Welt!\n");
	return 0;
}

