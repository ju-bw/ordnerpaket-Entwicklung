# Readme

% ju -- https://bw1.eu -- 10-Okt-18  -- Readme.md

## Hinweis

Projekt getestet unter Win10

## Software

Pandoc: <https://pandoc.org/installing.html>

Latex: <https://www.tug.org/texlive/acquire-netinstall.html>

~~~
  # Shell: TeXlive update
  tlmgr update --all
~~~

Editor: <https://code.visualstudio.com/download>

~~~
  # Editor visual studio code
  # Datei / einstellungen / User settings
  {
    "workbench.iconTheme": "material-icon-theme",
    "powershell.powerShellExePath": "C:\\WINDOWS\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
    "editor.tabSize": 2,           
    "php.executablePath": "C:/xampp/php/php.exe",
    "files.eol": "\n",
    "git.autofetch": true,
    "python.pythonPath": "D:\\anaconda\\python.exe",
    "window.zoomLevel": 1,
  }
~~~

Git: <https://git-scm.com/downloads>

~~~
  # Shell: Git version
  git --version
~~~

Imagemagick: <https://www.imagemagick.org/script/download.php#windows>


## Repository notizenDummy-v02 von Github downloaden

~~~
  # Shell: Kopie downloaden
  $ git clone https://github.com/ju-bw/notizenDummy-v02.git .
~~~

## neues Repository auf github anlegen

~~~
  # https://github.com/new
  # github: Create a new repository
  # Repository name = notizenDummy-v02
  # Shell: Git Befehle
  # ".gitconfig", ".gitignore" konfigurieren und erstellen
  git init
  git add .
  git commit -am "Projekt start"
  git remote add origin https://github.com/ju-bw/notizenDummy-v02.git
  git push -u origin master 
  git status
  git pull
  git push
  git status
~~~

## Markdown Dokumente / Notizen

Markdown Dokumente / Notizen im Ordner "md/neu.md" erstellen.

Beachte das *min. zwei Markdowndateien* vorhanden sein müssen. 

**Powershellscript** "docKonverter-v02.ps1" erstellt LaTeX - pdf und html files.

~~~
  # Editor - Powershellscript "docKonverter-v02.ps1" anpassen
    ### Projekt
    # anpassen
    $thema = "notizenDummy-v02" # Thema
    $bildformat = "svg"    # Bildformate: svg, jpg, png
    $codeformat = "sh"     # Codeformate: c, cpp, sh, py, ps1
    $language = "Powershell"   # Latex-Code:  C, [LaTeX]TeX, Bash, Python, Powershell
  # Shell: Script ausfuehren
  $ ./docKonverter-v02.ps1
~~~

## Bilder optimieren

**JPG Bilder** in den Ordner "imgOriginal/" kopieren.

**Powershellscript** "#imgWeb.ps1" optimiert Fotos für das Web und die PDF Datei.

~~~
  # Shell: Script ausfuehren
  $ ./imgWeb.ps1
~~~