# Bücher - Literaturangabe

Raspberry Pi Kochbuch\footfullcite{monk_raspberry:2014} Quelle \cite{monk_raspberry:2014}

Elektronik-Hacks \footfullcite{monk_elektronik_hacks:2013} Quelle \cite{monk_elektronik_hacks:2013}

Action-Buch\footfullcite{monk_action_buch:2016} Quelle  \cite{monk_action_buch:2016}

Quelle \footfullcite{weigend_raspberry:2016} Raspberry Pi programmieren mit Python \cite{weigend_raspberry:2016}

Quelle \footfullcite{weigend_python:2018} Python 3: Lernen und professionell anwenden. \cite{weigend_python:2018}



Quelle \footfullcite{bosch_training:2018} Bosch Training \cite{bosch_training:2018}

Quelle \footfullcite{schlosser_latex:2016} Latex \cite{schlosser_latex:2016}

Quelle \footfullcite{homofaciens_projekt:2018} homofaciens \cite{homofaciens_projekt:2018}

Quelle \footfullcite{frei_kfzelektrik:2013} Kfz Elektrik \cite{frei_kfzelektrik:2013}

Quelle \footfullcite{bartmann:2018} Bartmann \cite{bartmann:2018}

Quelle \footfullcite{bartmann_arduino:2017} Arduino \cite{bartmann_arduino:2017}

Quelle \footfullcite{joos_windows:2018} Joos \cite{joos_windows:2018}

Quelle \footfullcite{joos_win7:2012} Windows 7 \cite{joos_win7:2012}

Quelle \footfullcite{kofler:2018} Kofler \cite{kofler:2018}

Quelle \footfullcite{kofler_raspberry:2015} Raspberry \cite{kofler_raspberry:2015}

Quelle \footfullcite{kofler_linux:2017} Linux \cite{kofler_linux:2017}

Quelle \footfullcite{kofler_hacking:2018} Hacking \cite{kofler_hacking:2018}

Quelle \footfullcite{kofler_shellbefehle:2016} Shell Befehle \cite{kofler_shellbefehle:2016}

Quelle \footfullcite{kuveler_inf:2009} Informatik \cite{kuveler_inf:2009}

Quelle \footfullcite{loviscach:2018} Informatik \cite{loviscach:2018}

Quelle \footfullcite{riesinger_mathe:2017} Mathe \cite{riesinger_mathe:2017}

Quelle \footfullcite{riesinger_inf:2006} Informatik \cite{riesinger_inf:2006}

Quelle \footfullcite{schwichtenberg_ps:2017} Powershell \cite{schwichtenberg_ps:2017}

Quelle \footfullcite{heiderich_techn_probleme-c:2016} Programmieren \cite{heiderich_techn_probleme-c:2016}

Quelle \footfullcite{will_einfuehrung_c++:2014} Programmieren \cite{will_einfuehrung_c++:2014}

Quelle \footfullcite{preisel_git:2017} Git \cite{preisel_git:2017}

Quelle \footfullcite{theis_einstieg_c++:2017} Programmieren \cite{theis_einstieg_c++:2017}

Quelle \footfullcite{theis_einstieg_c:2017} Programmieren \cite{theis_einstieg_c:2017}

Quelle \footfullcite{theis_einstieg_php:2017} PHP \cite{theis_einstieg_php:2017}

Quelle \footfullcite{theis_einstieg_python:2017} Python \cite{theis_einstieg_python:2017}

Quelle \footfullcite{gaicher_programmieren_c:2012} Programmieren \cite{gaicher_programmieren_c:2012}

Quelle \footfullcite{plotzeneder_powerprojekte_c:2013} Powerprojekte \cite{plotzeneder_powerprojekte_c:2013}

Quelle \footfullcite{kuhlee_forensik:2012} Forensik \cite{kuhlee_forensik:2012}

Quelle \footfullcite{erickson_hacking:2008} Hacking \cite{erickson_hacking:2008}

Quelle \footfullcite{ernesti_python:2015} Python \cite{ernesti_python:2015}

Quelle \footfullcite{gaicher_avr_c:2015} AVR \cite{gaicher_avr_c:2015}
